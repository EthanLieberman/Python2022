import random,math


print(math.trunc(math.fabs(-45)))
